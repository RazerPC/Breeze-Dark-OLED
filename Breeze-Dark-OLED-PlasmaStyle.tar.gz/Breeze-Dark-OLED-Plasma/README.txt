Breeze Dark OLED — Plasma Style

This is a Plasma Style, not a KDE application color scheme.

It inherits all unspecified assets from KDE's stock Breeze Plasma theme
(FallbackTheme=default) and overrides only these backgrounds with #000000:

- widgets/background.svg              Widget/applet backgrounds
- widgets/translucentbackground.svg   Translucent widget backgrounds
- widgets/panel-background.svg        Plasma panel/taskbar
- widgets/tooltip.svg                 Tooltips
- dialogs/background.svg              Plasma popup/dialog backgrounds

The same overrides are also included under solid/ and translucent/
so Plasma's opacity modes do not fall back to a gray Breeze background.

Install:
System Settings → Colors & Themes → Plasma Style → Install from File…
Select the .tar.gz archive, then choose “Breeze Dark OLED”.

Your KDE .colors scheme remains independent.
